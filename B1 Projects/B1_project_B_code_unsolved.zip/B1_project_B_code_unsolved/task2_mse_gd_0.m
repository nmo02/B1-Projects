clear all;
close all;
clc;


rng(12345) % Random number generator seed. Comment it out to use random seed.

% Create training/val data
n_samples = 1000;
[X_train_val, regression_targets_train_val, class_labels_train_val] = create_data(n_samples);
%... rest is for you to implement ...
%...


% Optimize - Linear Regression - Gradient Descent
theta_opt = linear_regression_gd(X_train, y_train, ????, ????);

%...




function theta_opt = linear_regression_gd(X_train, y_train, learning_rate, iters_total)
    %....
    
    % Initialize theta
    theta_curr = zeros(n_features,1);  % Current theta

    for i = 1:iters_total
        % Compute gradients
        % ...

        % Update theta
        % ...

        % Compute cost
        %...

    end
    theta_opt = ?????
end


function mse = mean_squared_error(X, y, theta)
    % ...
end

