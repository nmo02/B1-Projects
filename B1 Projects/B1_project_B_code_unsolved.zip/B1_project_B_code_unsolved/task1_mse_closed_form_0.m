clear all;
close all;
clc;


rng(12345) % Random number generator seed. Comment it out to use random seed.

% Create training data
n_samples_train = 1000;
[X_train, regression_targets_train, class_labels_train] = create_data(n_samples_train);
y_train = regression_targets_train;  % Target for regression model - what to predict
class_labels_train = NaN;  % Wont be used for regression.
% concat 1 for bias
X_train = cat(2, ones(n_samples_train,1), X_train);

% Create testing data
n_samples_test = 20000;
[X_test, regression_targets_test, class_labels_test] = create_data(n_samples_test);
y_test = regression_targets_test;
class_labels_test = NaN;  % Wont be used for regression.
% concat 1 for bias
X_test = cat(2, ones(n_samples_test,1), X_test);

%... rest is up to you ...
%...


function mse = mean_squared_error(X, y, theta)
    % implement
    mse = ?????
end

function theta_opt = mse_regression_closed_form(X, y)
    % implement
    theta_opt = ?????
end




