clear all;
close all;
clc;

% Note: Remember to Change class labels {1,2} to values for y appropriate for log-regr => y={0,1}

rng(12345) % Random number generator seed. Comment it out to use random seed.

% Create training/val data
n_samples = 1000;
[X_train_val, regression_targets_train_val, class_labels_train_val] = create_data(n_samples);
y_train_val = (class_labels_train_val==1)*(0) + (class_labels_train_val==2)*(1); % If class 1, y=0. If class 2, y=1.
regression_targets_train_val = NaN;  % Wont be used for classification.
% concat 1 for bias
X_train_val = cat(2, ones(n_samples,1), X_train_val);

% ........

% Optimize - Logistic Regression - Gradient Descent
theta_opt = logistic_regression_gd(X_train, y_train, ?????, ??????);

% ........



function theta_opt = logistic_regression_gd(X_train, y_train, learning_rate, iters_total)
    % ...
end


function mean_logloss = mean_logloss(x, y_real, theta)
    %...
end


function y_pred = log_regr(X, theta)
    %...
end


function err_perc = classif_error(y_real, y_pred)
    %...
end
