clear all;
close all;
clc;

% Note: Remember to change class labels {1,2} to values for y appropriate for SVM => y={-1,+1}

rng(12345) % Random number generator seed. Comment it out to use random seed.

% Create training/val data
n_samples = 1000;
[X_train_val, regression_targets_train_val, class_labels_train_val] = create_data(n_samples);
y_train_val = (class_labels_train_val==1)*(-1) + (class_labels_train_val==2)*(1); % If class 1, y=-1. If class 2, y=+1
regression_targets_train_val = NaN;  % Wont be used for classification.
% concat 1 for bias
X_train_val = cat(2, ones(n_samples,1), X_train_val);

%...

% Optimize - Support Vector Machine - Gradient Descent with Hinge Loss
theta_opt = train_SVM_hingeloss_gd(X_train, y_train, ???????, ??????);

%...


function theta_opt = train_SVM_hingeloss_gd(X_train, y_train, learning_rate, iters_total)
    %...
    % Initialize parameters
    theta_curr = zeros(n_features,1);

    l%...

    for i = 1:iters_total
       %....
    end
    
    theta_opt = ?????
    
    %....

end


function loss_per_sample = hinge_loss_per_sample(X, y_true, theta)
    %...
end

function class_score = svm(X, theta)
    %....
end

function err_perc = classif_error(y_true, y_pred)
    %....
end







