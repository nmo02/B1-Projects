clear all;
close all;
clc;


% Note: Remember to Change class labels {1,2} to values for y appropriate for SVM => y={-1,+1}

rng(12345) % Random number generator seed. Comment it out to use random seed.

% Create training data
n_samples = 1000;
[X_train, regression_targets_train, class_labels_train] = create_data(n_samples);
y_train = (class_labels_train==1)*(-1) + (class_labels_train==2)*(1); % If class 1, y=-1. If class 2, y=+1
regression_targets_train = NaN;  % Wont be used for classification.
% concat 1 for bias
X_train = cat(2, ones(n_samples,1), X_train);

%...

% Optimize - Support Vector Machine - Linear Programming
theta_opt = train_SVM_linear_progr(X_train, y_train)

%...


function theta_opt = train_SVM_linear_progr(X_train, y_train)
    %...
end

function class_score = svm(X, theta)
    %...
end

function err_perc = classif_error(y_true, y_pred)
    %...
end



